﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace GroceryStoreApi.Models
{
    public class Item
    {
       
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("Name")]
        public string? name { get; set; } = "a";
        public string? nescription { get; set; } = "b";
        public decimal? price { get; set; }

    }
}
